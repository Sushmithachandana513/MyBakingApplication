package com.example.acer.mybakingapplication;

import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViewsService;

import static android.support.constraint.Constraints.TAG;

public class RemoteService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        Log.d(TAG, "onGetViewFactory: ");
        return new RemoteFactory(this.getApplication(),intent);
    }
}

package com.example.acer.mybakingapplication;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.acer.mybakingapplication.PojoClasses.Ingredients;

import java.util.ArrayList;
import java.util.List;

import static android.support.constraint.Constraints.TAG;
import static com.example.acer.mybakingapplication.NewAppWidget.ingredientsList;


public class RemoteFactory implements RemoteViewsService.RemoteViewsFactory {
    Context ct;
    Intent i;
    ArrayList<Ingredients> stringList;
    public RemoteFactory(Application application, Intent intent) {
        this.ct=application;
        this.i=intent;
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDataSetChanged() {
        stringList=ingredientsList;
        if(stringList!=null) {
            Log.d(TAG, "onCreate: " + stringList.size());
        }
    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        if(stringList!=null){
            return stringList.size();
        }else {
            return 0;
        }
    }

    @Override
    public RemoteViews getViewAt(int position) {
        RemoteViews remoteView=new RemoteViews(ct.getPackageName(),R.layout.grid_child);
        remoteView.setTextViewText(R.id.ingre,stringList.get(position).getIngredient());
        remoteView.setTextViewText(R.id.quality,stringList.get(position).getQuantity());
        remoteView.setTextViewText(R.id.measure,stringList.get(position).getMeasure());
        return remoteView;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }
}

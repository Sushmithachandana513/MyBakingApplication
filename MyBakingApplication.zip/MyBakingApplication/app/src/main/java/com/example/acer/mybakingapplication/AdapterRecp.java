package com.example.acer.mybakingapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.acer.mybakingapplication.PojoClasses.Ingredients;
import com.example.acer.mybakingapplication.PojoClasses.Recipe;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

class AdapterRecp extends RecyclerView.Adapter<AdapterRecp.ViewHolderRecp> {

    Context context;
    List<Recipe> recepiesList;
    public AdapterRecp(MainActivity mainActivity, List<Recipe> recepiesList) {

        this.context = mainActivity;
        this.recepiesList = recepiesList;
    }

    @NonNull
    @Override
    public ViewHolderRecp onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view=LayoutInflater.from(context).inflate(R.layout.itemrecp,viewGroup,false);
        return new ViewHolderRecp(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderRecp viewHolderRecp, int i) {

        viewHolderRecp.recpname.setText(recepiesList.get(i).getName());
    }



    @Override
    public int getItemCount() {
        return recepiesList.size();
    }

    public class ViewHolderRecp extends RecyclerView.ViewHolder {

        @InjectView(R.id.Recpnameid)
        TextView recpname;
        public ViewHolderRecp(@NonNull View itemView) {
            super(itemView);

            ButterKnife.inject(this, itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position=getAdapterPosition();
                    if (position!=RecyclerView.NO_POSITION){
                        Intent intent=new Intent(context,ItemListActivity.class);
                        intent.putExtra("stepsList",(Serializable)recepiesList.get(position).getSteps());
                        intent.putExtra("ingridents",(Serializable)recepiesList.get(position).getIngredients());
                        context.startActivity(intent);

                        List<Ingredients> ingredientsList=recepiesList.get(position).getIngredients();
                        Intent i=new Intent(context,IntentService.class);
                        i.setAction("MyServiceCall");
                        i.putExtra("ingre", (Serializable) ingredientsList);
                        context.startService(i);

                    }
                }
            });
        }
    }
}

package com.example.acer.mybakingapplication;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.acer.mybakingapplication.PojoClasses.Ingredients;
import com.example.acer.mybakingapplication.PojoClasses.Step;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;


public class ItemListActivity extends AppCompatActivity {


    private boolean mTwoPane;

    ArrayList<Ingredients> ingredientArrayList;
    ArrayList<Step> stepArrayList;
    @InjectView(R.id.item_list)
    RecyclerView recycleritem;
    StringBuilder stringBuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(getTitle());


        ingredientArrayList = new ArrayList<>();
        stepArrayList = new ArrayList<>();
        ButterKnife.inject(this);
        ingredientArrayList = (ArrayList<Ingredients>) getIntent().getSerializableExtra("ingridents");
        stepArrayList = (ArrayList<Step>) getIntent().getSerializableExtra("stepsList");
        stringBuilder=new StringBuilder();
        for (int i=0;i<ingredientArrayList.size();i++)
        {
            stringBuilder.append(ingredientArrayList.get(i).getIngredient() + ":\t"+
                    ingredientArrayList.get(i).getQuantity()+"\t"+ingredientArrayList.get(i).getMeasure()+"\n");
        }

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog=new Dialog(ItemListActivity.this);
                dialog.setContentView(R.layout.dialog);
                dialog.setTitle("INGREDIENTS:");


                TextView textView=dialog.findViewById(R.id.dialogView);
                textView.setText(stringBuilder.toString());
                dialog.show();
            }
        });

        if (findViewById(R.id.item_detail_container) != null) {


            mTwoPane = true;
        }

        View recyclerView = findViewById(R.id.item_list);
        assert recyclerView != null;
        setupRecyclerView((RecyclerView) recyclerView);
    }

    private void setupRecyclerView(@NonNull RecyclerView recyclerView) {
        recyclerView.setAdapter(new SimpleItemRecyclerViewAdapter(this, stepArrayList, mTwoPane));
    }

    public static class SimpleItemRecyclerViewAdapter
            extends RecyclerView.Adapter<SimpleItemRecyclerViewAdapter.ViewHolder> {

        private final ItemListActivity mParentActivity;
        private final List<Step> mValues;
        private final boolean mTwoPane;
        /* private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DummyContent.DummyItem item = (DummyContent.DummyItem) view.getTag();
                if (mTwoPane) {
                    Bundle arguments = new Bundle();
                    arguments.putString(ItemDetailFragment.ARG_ITEM_ID, item.id);
                    ItemDetailFragment fragment = new ItemDetailFragment();
                    fragment.setArguments(arguments);
                    mParentActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.item_detail_container, fragment)
                            .commit();
                } else {
                    Context context = view.getContext();
                    Intent intent = new Intent(context, ItemDetailActivity.class);
                    intent.putExtra(ItemDetailFragment.ARG_ITEM_ID, item.id);

                    context.startActivity(intent);
                }
            }
        };*/

        SimpleItemRecyclerViewAdapter(ItemListActivity parent,
                                      List<Step> items,
                                      boolean twoPane) {
            mValues = items;
            mParentActivity = parent;
            mTwoPane = twoPane;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, int position) {
            holder.mIdView.setText(mValues.get(position).getId().toString());
            holder.mContentView.setText(mValues.get(position).getShortDescription());
            //holder.itemView.setTag(mValues.get(position));
            //holder.itemView.setOnClickListener(mOnClickListener);
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            final TextView mIdView;
            final TextView mContentView;

            ViewHolder(View view) {
                super(view);
                mIdView = (TextView) view.findViewById(R.id.id_text);
                mContentView = (TextView) view.findViewById(R.id.content);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int recpos = getAdapterPosition();
                        if (mTwoPane) {
                            Bundle arguments = new Bundle();
                            arguments.putString("Videourl",mValues.get(recpos).getVideoURL());
                            arguments.putString("Description",mValues.get(recpos).getDescription());
                            arguments.putString("thumbnail",mValues.get(recpos).getThumbnailURL());
                            ItemDetailFragment fragment = new ItemDetailFragment();
                            fragment.setArguments(arguments);
                            mParentActivity.getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.item_detail_container, fragment)
                                    .commit();
                        } else {
                            Intent intent = new Intent(mParentActivity, ItemDetailActivity.class);
                            intent.putExtra("Videourl", mValues.get(recpos).getVideoURL());
                            intent.putExtra("Description", mValues.get(recpos).getDescription());
                            intent.putExtra("thumbnail",mValues.get(recpos).getThumbnailURL());
                            mParentActivity.startActivity(intent);
                        }
                    }
                });
            }
        }
    }
}

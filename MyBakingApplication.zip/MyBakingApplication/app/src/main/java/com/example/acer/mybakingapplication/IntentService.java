package com.example.acer.mybakingapplication;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.util.Log;

import static android.support.constraint.Constraints.TAG;

public class IntentService extends android.app.IntentService {

    public IntentService() {
        super("MyService");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        if (intent!=null)
        {
            if (intent.getAction().equals("MyServiceCall"))
            {
                Log.d(TAG, "onHandleIntent: ");
                Intent i=new Intent("com.example.acer.mybakingapplication");
                i.putExtra("ingre",intent.getSerializableExtra("ingre"));
                sendBroadcast(i);

            }
        }

    }
}

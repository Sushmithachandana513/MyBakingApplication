package com.example.acer.mybakingapplication;

import android.app.ProgressDialog;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.acer.mybakingapplication.PojoClasses.Recipe;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;

import butterknife.InjectView;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {

    @InjectView(R.id.recymainid)
    RecyclerView recyclerView;
    List<Recipe> recepiesList;
    ProgressDialog pd;
    InputStream inputStream;
    Scanner scanner;
    String Url = "https://d17h27t6h515a5.cloudfront.net/topher/2017/May/59121517_baking/baking.json";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         butterknife.ButterKnife.inject(this);
        pd = new ProgressDialog(this);
        getSupportLoaderManager().initLoader(1, null, this);
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int i, @Nullable Bundle bundle) {
        return new AsyncTaskLoader<String>(this) {


            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                forceLoad();
                pd.setTitle("Loading Content");
                pd.setMessage("please wait...");
                pd.setCancelable(false);
                pd.show();
            }


            @Nullable
            @Override
            public String loadInBackground() {
                try {
                    URL url = new URL(Url);
                    HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();
                    inputStream = urlConnection.getInputStream();
                    scanner = new Scanner(inputStream);
                    scanner.useDelimiter("\\A");
                    boolean hasinput = scanner.hasNext();
                    if (hasinput) {
                        return scanner.next();
                    } else {
                        return null;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String s) {
        pd.dismiss();
        //Toast.makeText(this, ""+s.length(), Toast.LENGTH_SHORT).show();
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        recepiesList = new ArrayList<>();
        recepiesList = Arrays.asList(gson.fromJson(s, Recipe[].class));
        AdapterRecp adapterRecp = new AdapterRecp(MainActivity.this, recepiesList);
        recyclerView.setAdapter(adapterRecp);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {



    }
}

package com.example.acer.mybakingapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.design.widget.CollapsingToolbarLayout;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.media.session.PlaybackStateCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.acer.mybakingapplication.dummy.DummyContent;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.squareup.picasso.Picasso;


public class ItemDetailFragment extends Fragment {

    String videourl, shortdesc,thumbnail;
    SimpleExoPlayerView simpleExoPlayerView;
    SimpleExoPlayer simpleExoPlayer;
    PlaybackStateCompat.Builder playback=new PlaybackStateCompat.Builder();
    boolean playwhenready;
    ImageView imageView;
    long currentposition;
    String link;
    boolean port;


    public ItemDetailFragment() {


    }
    @SuppressLint("ValidFragment")
    public ItemDetailFragment(boolean orientation_port)
    {
        port=orientation_port;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments().containsKey("Videourl")) {
            videourl = getArguments().getString("Videourl");
            shortdesc = getArguments().getString("Description");
            thumbnail=getArguments().getString("thumbnail");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.item_detail, container, false);
        imageView=rootView.findViewById(R.id.imageView);
        simpleExoPlayerView = rootView.findViewById(R.id.exoid);
        ((TextView) rootView.findViewById(R.id.descid)).setText(shortdesc);

        int orientation=getResources().getConfiguration().orientation;
        if(orientation== Configuration.ORIENTATION_LANDSCAPE)
        {
            ((TextView) rootView.findViewById(R.id.descid)).setVisibility(View.GONE);
        }

        else {
            ((TextView) rootView.findViewById(R.id.descid)).setVisibility(View.VISIBLE);
        }

        simpleExoPlayerView.setDefaultArtwork(BitmapFactory.decodeResource(getResources(),R.drawable.video));
        initializePlayer();

        if(savedInstanceState!=null)
        {
            currentposition = savedInstanceState.getLong("cuposition");
            simpleExoPlayer.seekTo(currentposition);
            boolean currentplay = savedInstanceState.getBoolean("currentplay");
            simpleExoPlayer.setPlayWhenReady(currentplay);

        }

        return rootView;
    }



    private void initializePlayer() {

        if(videourl.equalsIgnoreCase("")){
            if(!thumbnail.isEmpty()){
                videourl=thumbnail;
                imageView.setVisibility(View.VISIBLE);
                simpleExoPlayerView.setDefaultArtwork(BitmapFactory.decodeResource(getResources(),R.drawable.video));
                Picasso.with(getContext()).load(thumbnail).placeholder(R.drawable.video).into(imageView);
                simpleExoPlayerView.setVisibility(View.VISIBLE);
            }else {
                simpleExoPlayerView.setVisibility(View.VISIBLE);
            }
        }

        BandwidthMeter bandwidthMeter=new DefaultBandwidthMeter();
        TrackSelector trackSelector=new DefaultTrackSelector(new AdaptiveTrackSelection.Factory(bandwidthMeter));
        LoadControl loadControl=new DefaultLoadControl();
        simpleExoPlayer=ExoPlayerFactory.newSimpleInstance(getContext(),trackSelector,loadControl);

        simpleExoPlayer = ExoPlayerFactory.newSimpleInstance(
                new DefaultRenderersFactory(getActivity()),
                new DefaultTrackSelector(), new DefaultLoadControl());

        Uri uri = Uri.parse(videourl);
        MediaSource mediaSource = buildMediaSource(uri);
        simpleExoPlayer.prepare(mediaSource);
        simpleExoPlayerView.setPlayer(simpleExoPlayer);
        simpleExoPlayer.setPlayWhenReady(playwhenready);
    }

    private MediaSource buildMediaSource(Uri uri) {
        return new ExtractorMediaSource.Factory(
                new DefaultHttpDataSourceFactory("exoplayer-codelab")).
                createMediaSource(uri);
    }


    @Override
    public void onResume() {
        super.onResume();
        if ((Util.SDK_INT <23 || simpleExoPlayer == null)) {
            initializePlayer();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        simpleExoPlayer.release();
        simpleExoPlayer.stop();
    }


   public void onSaveInstanceState(Bundle outstate){
        super.onSaveInstanceState(outstate);
        outstate.putLong("cuposition",simpleExoPlayer.getCurrentPosition());
        outstate.putBoolean("currentplay",simpleExoPlayer.getPlayWhenReady());
   }
}


